import React from 'react';
import CalculatorD20 from './CalculatorD20';

/**
 * Calculator
 * All modes now use the D20 calculator.
 * This thin wrapper is kept so existing import paths don't need to change.
 */
const Calculator = ({
  data,
  players,
  npcs = [],
  onClose,
  onProceedToDistribution,
  gameMode = 'campaign',
  firstStrike = false,
  onUpdatePlayer = () => {},
  onAddLog = () => {},
  onEndTurn = null,
}) => (
  <CalculatorD20
    data={data}
    players={players}
    npcs={npcs}
    onClose={onClose}
    onProceedToDistribution={onProceedToDistribution}
    firstStrike={firstStrike}
    onUpdatePlayer={onUpdatePlayer}
    onAddLog={onAddLog}
    onEndTurn={onEndTurn}
  />
);

export default Calculator;